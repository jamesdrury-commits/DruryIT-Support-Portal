#!/bin/sh
set -eu
# Run as root on DruSAN after copying the druryit-support-server directory there.
# Adjust WEBROOT only if your Web Station document root differs.
WEBROOT="${WEBROOT:-/volume1/web/support.druryit.com}"
PRIVATE="${PRIVATE:-/volume1/web_private/druryit-support}"

mkdir -p "$WEBROOT/api" "$PRIVATE"
cp index.php "$WEBROOT/index.php"
cp health.php "$WEBROOT/health.php"
cp ticket.php "$WEBROOT/api/ticket.php"

if [ ! -f "$PRIVATE/config.php" ]; then
  cp config.example.php "$PRIVATE/config.php"
  chmod 600 "$PRIVATE/config.php"
  echo "Created $PRIVATE/config.php — EDIT SMTP ADDRESS/USERNAME/PASSWORD before testing."
fi
chmod 755 "$WEBROOT" "$WEBROOT/api"
chmod 644 "$WEBROOT/index.php" "$WEBROOT/health.php" "$WEBROOT/api/ticket.php"
echo "Installed DruryIT Support API files under $WEBROOT"
echo "Private SMTP/token config: $PRIVATE/config.php"
echo "NOTE: ticket.php expects private config at /volume1/web_private/druryit-support/config.php."
