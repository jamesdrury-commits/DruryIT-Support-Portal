<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

function fail(int $status, string $message): never {
    http_response_code($status);
    echo json_encode(['ok'=>false,'error'=>$message]);
    exit;
}
function cleanHeader(string $s): string { return trim(preg_replace('/[\r\n]+/', ' ', $s)); }
function smtpRead($fp): string {
    $out='';
    while (($line=fgets($fp, 8192)) !== false) {
        $out .= $line;
        if (strlen($line) >= 4 && $line[3] === ' ') break;
    }
    return $out;
}
function smtpCmd($fp, string $cmd, array $okCodes): string {
    fwrite($fp, $cmd."\r\n");
    $r=smtpRead($fp);
    $code=(int)substr($r,0,3);
    if (!in_array($code,$okCodes,true)) throw new RuntimeException("SMTP command failed ($code)");
    return $r;
}
function sendSmtp(array $cfg, string $from, string $fromName, string $to, string $subject, string $body, array $attachments): void {
    $smtp=$cfg['smtp'];
    $host=(string)$smtp['host']; $port=(int)$smtp['port']; $enc=strtolower((string)($smtp['encryption']??'tls'));
    $remote=($enc==='ssl'?'ssl://':'tcp://').$host.':'.$port;
    $ctx=stream_context_create(['ssl'=>['verify_peer'=>true,'verify_peer_name'=>true,'allow_self_signed'=>false]]);
    $fp=@stream_socket_client($remote,$errno,$errstr,20,STREAM_CLIENT_CONNECT,$ctx);
    if (!$fp) throw new RuntimeException('SMTP connection failed');
    stream_set_timeout($fp,20);
    $greeting=smtpRead($fp); if ((int)substr($greeting,0,3)!==220) throw new RuntimeException('SMTP greeting failed');
    $helo=gethostname() ?: 'druryit.local';
    smtpCmd($fp,"EHLO $helo",[250]);
    if ($enc==='tls') {
        smtpCmd($fp,'STARTTLS',[220]);
        if (!stream_socket_enable_crypto($fp,true,STREAM_CRYPTO_METHOD_TLS_CLIENT)) throw new RuntimeException('SMTP TLS failed');
        smtpCmd($fp,"EHLO $helo",[250]);
    }
    if (!empty($smtp['username'])) {
        smtpCmd($fp,'AUTH LOGIN',[334]);
        smtpCmd($fp,base64_encode((string)$smtp['username']),[334]);
        smtpCmd($fp,base64_encode((string)$smtp['password']),[235]);
    }
    smtpCmd($fp,'MAIL FROM:<'.$from.'>',[250]);
    smtpCmd($fp,'RCPT TO:<'.$to.'>',[250,251]);
    smtpCmd($fp,'DATA',[354]);

    $boundary='=_DruryIT_'.bin2hex(random_bytes(12));
    $headers=[];
    $headers[]='From: '.cleanHeader($fromName).' <'.cleanHeader($from).'>';
    $headers[]='To: <'.cleanHeader($to).'>';
    $headers[]='Subject: '.cleanHeader($subject);
    $headers[]='MIME-Version: 1.0';
    $headers[]='Content-Type: multipart/mixed; boundary="'.$boundary.'"';
    $headers[]='Date: '.date(DATE_RFC2822);
    $headers[]='Message-ID: <'.bin2hex(random_bytes(10)).'@'.($helo?:'druryit.local').'>';

    $msg=implode("\r\n",$headers)."\r\n\r\n";
    $msg.='--'.$boundary."\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: 8bit\r\n\r\n".$body."\r\n";
    foreach ($attachments as $a) {
        $data=file_get_contents($a['tmp']);
        if ($data===false) continue;
        $name=str_replace(['"',"\r","\n"],'_',basename($a['name']));
        $msg.='--'.$boundary."\r\n";
        $msg.='Content-Type: application/octet-stream; name="'.$name."'\r\n";
        $msg.='Content-Disposition: attachment; filename="'.$name."'\r\n";
        $msg.="Content-Transfer-Encoding: base64\r\n\r\n";
        $msg.=chunk_split(base64_encode($data),76,"\r\n");
    }
    $msg.='--'.$boundary."--\r\n";
    $msg=preg_replace('/\r?\n\./',"\r\n..",$msg);
    fwrite($fp,$msg."\r\n.\r\n");
    $r=smtpRead($fp); if ((int)substr($r,0,3)!==250) throw new RuntimeException('SMTP delivery rejected');
    @smtpCmd($fp,'QUIT',[221]);
    fclose($fp);
}

if ($_SERVER['REQUEST_METHOD']!=='POST') fail(405,'POST required');
$configFile='/volume1/web_private/druryit-support/config.php';
if (!is_file($configFile)) fail(500,'Server is not configured');
$config=require $configFile;
$auth=$_SERVER['HTTP_AUTHORIZATION']??'';
if (!preg_match('/^Bearer\s+(.+)$/i',$auth,$m)) fail(401,'Missing deployment token');
$token=trim($m[1]);
$client=$config['client_tokens'][$token]??null;
if (!$client) fail(403,'Invalid deployment token');
if (!isset($_POST['ticket'])) fail(400,'Missing ticket data');
$data=json_decode((string)$_POST['ticket'],true);
if (!is_array($data)) fail(400,'Invalid ticket JSON');
$problem=trim((string)($data['problem']??''));
if ($problem==='') fail(400,'Problem description is required');

$ticketId='DIT-'.date('Ymd-His').'-'.strtoupper(bin2hex(random_bytes(2)));
$clientName=(string)($client['client_name']??'Unknown Client');
$clientId=(string)($client['client_id']??'');
$computer=trim((string)($data['computerName']??'Unknown PC'));
$user=trim((string)($data['userName']??'Unknown User'));
$priority=trim((string)($data['priority']??'Normal'));
$bestTime=trim((string)($data['bestTime']??'Any time'));
$windows=trim((string)($data['windowsVersion']??''));
$submitted=trim((string)($data['submittedAtLocal']??''));

$max=(int)($config['max_attachment_bytes']??8388608); $maxCount=(int)($config['max_attachments']??5);
$allowed=array_map('strtolower',$config['allowed_extensions']??[]); $attachments=[];
if (isset($_FILES['attachments']) && is_array($_FILES['attachments']['name']??null)) {
    $f=$_FILES['attachments']; $count=count($f['name']); if ($count>$maxCount) fail(400,'Too many attachments');
    for ($i=0;$i<$count;$i++) {
        if ((int)$f['error'][$i]===UPLOAD_ERR_NO_FILE) continue;
        if ((int)$f['error'][$i]!==UPLOAD_ERR_OK) fail(400,'Attachment upload failed');
        $size=(int)$f['size'][$i]; if ($size<=0 || $size>$max) fail(400,'Attachment too large');
        $name=basename((string)$f['name'][$i]); $ext=strtolower(pathinfo($name,PATHINFO_EXTENSION));
        if (!in_array($ext,$allowed,true)) fail(400,'Attachment type not allowed');
        $attachments[]=['tmp'=>(string)$f['tmp_name'][$i],'name'=>$name];
    }
}

$body="New DruryIT Support Request\n\nTicket: $ticketId\nClient: $clientName\nClient ID: $clientId\nUser: $user\nComputer: $computer\nPriority: $priority\nBest time to connect: $bestTime\nWindows: $windows\nSubmitted from client: $submitted\nReceived by server: ".date('c')."\n\nProblem:\n$problem\n";
$subject="DruryIT Support — $clientName — $computer — $ticketId";
try {
    sendSmtp($config,(string)$config['support_from'],(string)$config['support_from_name'],(string)$config['support_to'],$subject,$body,$attachments);
} catch (Throwable $e) {
    error_log("DruryIT $ticketId mail error: ".$e->getMessage());
    fail(502,'Ticket received but email delivery failed');
}

$logDir='/volume1/web_private/druryit-support'; if (!is_dir($logDir)) @mkdir($logDir,0700,true);
$log=json_encode(['ticket_id'=>$ticketId,'received_at'=>date('c'),'client_id'=>$clientId,'client_name'=>$clientName,'computer'=>$computer,'user'=>$user,'priority'=>$priority],JSON_UNESCAPED_SLASHES).PHP_EOL;
@file_put_contents($logDir.'/tickets.log',$log,FILE_APPEND|LOCK_EX);
echo json_encode(['ok'=>true,'ticketId'=>$ticketId]);
