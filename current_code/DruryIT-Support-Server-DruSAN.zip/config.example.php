<?php
return [
    'support_to' => 'YOUR-SUPPORT-INBOX@example.com',
    'support_from' => 'YOUR-SMTP-SENDER@example.com',
    'support_from_name' => 'DruryIT Support',

    'smtp' => [
        'host' => 'smtp.example.com',
        'port' => 587,
        'username' => 'YOUR-SMTP-USERNAME',
        'password' => 'YOUR-SMTP-APP-PASSWORD',
        'encryption' => 'tls', // tls or ssl
    ],

    // Test client token generated with this build.
    'client_tokens' => [
        'dSev1OcYIFtXknvLm9EP7QV7EfR7iYlyLHz1dFMZ4iFOGS-z' => [
            'client_id' => 'druryit-test',
            'client_name' => 'DruryIT Test',
        ],
    ],

    'max_attachment_bytes' => 8 * 1024 * 1024,
    'max_attachments' => 5,
    'allowed_extensions' => ['png','jpg','jpeg','gif','pdf','txt','log'],
];
